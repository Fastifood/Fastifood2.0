    function mascaraTelefone(event) {
        let input = event.target;
        let telefone = input.value.replace(/\D/g, '');
        telefone = telefone.replace(/^(\d{2})(\d)/g, '($1) $2');
        telefone = telefone.replace(/(\d)(\d{4})$/, '$1-$2');
        input.value = telefone;
    }

    function limitarCaracteres(event) {
        let input = event.target;
        if (input.value.length > 15) {
            input.value = input.value.slice(0, 15);
        }
    }